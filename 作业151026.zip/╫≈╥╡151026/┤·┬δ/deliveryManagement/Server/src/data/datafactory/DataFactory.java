package data.datafactory;

/**
 * Created by Administrator on 2015/10/26 0026.
 */
public class DataFactory {
}
