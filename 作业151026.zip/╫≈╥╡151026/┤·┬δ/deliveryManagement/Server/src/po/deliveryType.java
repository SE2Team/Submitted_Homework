package po;

/**
 * Created by Administrator on 2015/10/24 0024.
 */
public enum DeliveryType {
    NORMAL,FAST
}
