package src.enumClass;

public enum PositionType {
		COURIER,MANAGER,FINANCIAL,STOCKMANAGER,SALESMAN,TRANSFERMAN;
}
