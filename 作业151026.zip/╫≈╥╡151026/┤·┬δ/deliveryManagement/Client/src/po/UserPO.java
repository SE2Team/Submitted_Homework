package src.po;

public class UserPO {

}
