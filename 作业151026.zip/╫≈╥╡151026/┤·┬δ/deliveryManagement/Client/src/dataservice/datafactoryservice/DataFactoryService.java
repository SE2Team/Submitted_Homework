package src.dataservice.datafactoryservice;

import src.dataservice.listdataservice.ListDataService;

public interface DataFactoryService {
    public ListDataService getListDataService();

}
