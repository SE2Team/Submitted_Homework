package src.vo;

public class UserVO {

}
