package src.vo;

public class VehicleVO {

}
