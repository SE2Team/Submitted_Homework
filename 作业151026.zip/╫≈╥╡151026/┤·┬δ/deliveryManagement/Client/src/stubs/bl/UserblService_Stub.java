package src.stubs.bl;

import src.businesslogicservice.UserblService;
import src.vo.UserVO;

public class UserblService_Stub implements UserblService{
	
	public UserblService_Stub(){
		
	}
	
	
	public boolean login(String userID,String password){
		// TODO Auto-generated method stub
    	return true;
	}
	public boolean add(UserVO userVO){
		// TODO Auto-generated method stub
    	return true;
	}
	public boolean delete(UserVO userVO){
		// TODO Auto-generated method stub
    	return true;
	}
	public boolean modify(UserVO userVOOld,UserVO userVONew){
		// TODO Auto-generated method stub
    	return true;
	}

}
